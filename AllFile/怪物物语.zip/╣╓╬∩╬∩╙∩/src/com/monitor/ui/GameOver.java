package com.monitor.ui;

import java.awt.image.BufferedImage;

import com.monitor.objects.FlyingObject;

public class GameOver extends FlyingObject{

	public GameOver(int x, int y,BufferedImage image) {
		super(x, y, 400, 600, image);
	}

}
