package com.monitor.main;

import javax.swing.JFrame;

import com.monitor.source.Resources;
import com.monitor.ui.GameFrame;
import com.monitor.ui.GameStart;

public class Main {

	/**
	 * @param args 
	 */
	public static void main(String[] args) {
	
		new GameStart();

	}

}
